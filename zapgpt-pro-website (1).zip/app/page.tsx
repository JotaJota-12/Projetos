"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  MessageCircle,
  Smartphone,
  Zap,
  Shield,
  Clock,
  Star,
  Check,
  Bot,
  Send,
  Menu,
  X,
  Play,
  CheckCircle,
  Sparkles,
  TrendingUp,
  Globe,
  HeadphonesIcon,
} from "lucide-react"

export default function ZapGPTProLanding() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  // Animação de digitação para o título do Hero
  const [typingText, setTypingText] = useState("")
  const fullText = "Converse com uma IA no WhatsApp em segundos"

  useEffect(() => {
    let index = 0
    const timer = setInterval(() => {
      if (index < fullText.length) {
        setTypingText(fullText.slice(0, index + 1))
        index++
      } else {
        clearInterval(timer)
      }
    }, 100)

    return () => clearInterval(timer)
  }, [])

  const plans = [
    {
      id: "free",
      name: "Gratuito",
      price: "R$ 0",
      period: "/mês",
      description: "Perfeito para experimentar",
      features: ["15 mensagens por dia", "Respostas básicas da IA", "Suporte por email", "Histórico de 7 dias"],
      popular: false,
      buttonText: "Começar Grátis",
      buttonVariant: "outline" as const,
      savings: null,
    },
    {
      id: "premium",
      name: "Premium",
      price: "R$ 19,90",
      period: "/mês",
      originalPrice: "R$ 39,90",
      description: "Mais popular - Uso ilimitado",
      features: [
        "Mensagens ilimitadas",
        "IA mais avançada (GPT-4)",
        "Respostas prioritárias",
        "Histórico completo",
        "Suporte 24/7",
        "Análise de documentos",
        "Sem anúncios",
        "Acesso antecipado a novidades",
      ],
      popular: true,
      buttonText: "Assinar Premium",
      buttonVariant: "default" as const,
      savings: "50% OFF",
    },
    {
      id: "business",
      name: "Business",
      price: "R$ 49,90",
      period: "/mês",
      description: "Para empresas e equipes",
      features: [
        "Tudo do Premium",
        "Múltiplos usuários",
        "API personalizada",
        "Relatórios detalhados",
        "Integração com sistemas",
        "Gerente de conta dedicado",
        "SLA garantido",
        "Treinamento personalizado",
      ],
      popular: false,
      buttonText: "Falar com Vendas",
      buttonVariant: "outline" as const,
      savings: null,
    },
  ]

  const testimonials = [
    {
      name: "Carlos Mendes",
      role: "Empresário • São Paulo",
      content:
        "Revolucionou minha produtividade! Uso para resolver dúvidas rápidas sem sair do WhatsApp. A IA é impressionante e sempre disponível.",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
      verified: true,
    },
    {
      name: "Ana Beatriz",
      role: "Estudante de Medicina • Rio de Janeiro",
      content:
        "Perfeito para estudos! Me ajuda com conceitos complexos, resumos e até correção de textos. Não consigo mais estudar sem!",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
      verified: true,
    },
    {
      name: "Roberto Silva",
      role: "Desenvolvedor • Belo Horizonte",
      content:
        "Uso diariamente para resolver bugs e aprender novas tecnologias. A integração com WhatsApp é genial, muito mais prático que outros apps.",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
      verified: true,
    },
  ]

  const features = [
    {
      icon: <Clock className="h-8 w-8 text-green-600" />,
      title: "Disponível 24/7",
      description:
        "IA sempre online, pronta para responder suas dúvidas a qualquer hora, inclusive fins de semana e feriados",
    },
    {
      icon: <Smartphone className="h-8 w-8 text-green-600" />,
      title: "Direto no WhatsApp",
      description: "Sem apps extras ou cadastros complicados. Use no WhatsApp que você já tem no celular",
    },
    {
      icon: <Shield className="h-8 w-8 text-green-600" />,
      title: "100% Seguro",
      description: "Suas conversas são criptografadas e protegidas. Não armazenamos dados pessoais",
    },
    {
      icon: <Zap className="h-8 w-8 text-green-600" />,
      title: "Respostas Instantâneas",
      description: "Obtenha respostas em segundos, sem espera ou filas. Mais rápido que qualquer pesquisa no Google",
    },
    {
      icon: <Bot className="h-8 w-8 text-green-600" />,
      title: "IA Mais Avançada",
      description: "Powered by GPT-4, a inteligência artificial mais avançada e precisa disponível no mercado",
    },
    {
      icon: <Globe className="h-8 w-8 text-green-600" />,
      title: "Qualquer Assunto",
      description: "Estudos, trabalho, curiosidades, receitas, códigos, traduções e muito mais. Sem limites!",
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Header/Navigation */}
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-gray-100 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-green-600 rounded-xl flex items-center justify-center">
                <MessageCircle className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-900">ZapGPT Pro</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              <a href="#como-funciona" className="text-gray-600 hover:text-green-600 transition-colors">
                Como Funciona
              </a>
              <a href="#vantagens" className="text-gray-600 hover:text-green-600 transition-colors">
                Vantagens
              </a>
              <a href="#planos" className="text-gray-600 hover:text-green-600 transition-colors">
                Planos
              </a>
              <a href="#depoimentos" className="text-gray-600 hover:text-green-600 transition-colors">
                Depoimentos
              </a>
            </nav>

            <div className="hidden md:flex items-center gap-4">
              <Button variant="outline" className="border-green-600 text-green-600 hover:bg-green-50 bg-transparent">
                Login
              </Button>
              <Button className="bg-green-600 hover:bg-green-700 text-white">
                <MessageCircle className="mr-2 h-4 w-4" />
                Testar Grátis
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <Button variant="ghost" size="sm" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden mt-4 pb-4 border-t border-gray-100">
              <nav className="flex flex-col gap-4 mt-4">
                <a href="#como-funciona" className="text-gray-600 hover:text-green-600 transition-colors">
                  Como Funciona
                </a>
                <a href="#vantagens" className="text-gray-600 hover:text-green-600 transition-colors">
                  Vantagens
                </a>
                <a href="#planos" className="text-gray-600 hover:text-green-600 transition-colors">
                  Planos
                </a>
                <a href="#depoimentos" className="text-gray-600 hover:text-green-600 transition-colors">
                  Depoimentos
                </a>
                <div className="flex flex-col gap-2 mt-4">
                  <Button variant="outline" className="border-green-600 text-green-600 bg-transparent">
                    Login
                  </Button>
                  <Button className="bg-green-600 hover:bg-green-700 text-white">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Testar Grátis
                  </Button>
                </div>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-green-50 via-white to-green-50 pt-24 pb-20 px-4 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-green-100 rounded-full opacity-20"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-green-100 rounded-full opacity-20"></div>
        </div>

        <div className="max-w-7xl mx-auto relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-6">
                <Badge className="bg-green-100 text-green-800 hover:bg-green-100 px-4 py-2 text-sm font-medium">
                  🚀 Mais de 50.000 usuários ativos
                </Badge>

                <h1 className="text-4xl md:text-6xl font-bold text-gray-900 leading-tight">
                  <span className="block">{typingText}</span>
                  <span className="text-green-600 block mt-2">sem complicação!</span>
                </h1>

                <p className="text-xl text-gray-600 leading-relaxed max-w-lg">
                  A inteligência artificial mais avançada do mundo agora funciona diretamente no seu WhatsApp.
                  <strong className="text-gray-900"> Sem apps extras, sem cadastros complicados.</strong>
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 text-lg shadow-lg hover:shadow-xl transition-all"
                >
                  <MessageCircle className="mr-2 h-5 w-5" />
                  Começar Grátis Agora
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-green-600 text-green-600 hover:bg-green-50 px-8 py-4 text-lg bg-white"
                >
                  <Play className="mr-2 h-5 w-5" />
                  Ver Demonstração
                </Button>
              </div>

              <div className="flex items-center gap-8 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span>Teste grátis por 7 dias</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-green-600" />
                  <span>100% Seguro</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-green-600" />
                  <span>Disponível 24/7</span>
                </div>
              </div>
            </div>

            {/* Mockup do WhatsApp */}
            <div className="relative">
              <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-3xl p-8 shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500">
                <div className="bg-white rounded-2xl p-6 space-y-4 transform -rotate-3">
                  {/* Header do WhatsApp */}
                  <div className="flex items-center gap-3 pb-4 border-b border-gray-100">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center">
                      <Bot className="h-7 w-7 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">ZapGPT Pro</h3>
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <p className="text-sm text-green-600">Online agora</p>
                      </div>
                    </div>
                  </div>

                  {/* Conversa Simulada */}
                  <div className="space-y-3 max-h-80 overflow-hidden">
                    <div className="bg-gray-100 rounded-2xl rounded-tl-sm p-3 max-w-xs">
                      <p className="text-sm text-gray-700">👋 Olá! Sou sua IA pessoal. Como posso te ajudar hoje?</p>
                    </div>

                    <div className="bg-green-600 text-white rounded-2xl rounded-tr-sm p-3 max-w-xs ml-auto">
                      <p className="text-sm">Me explique sobre inteligência artificial de forma simples</p>
                    </div>

                    <div className="bg-gray-100 rounded-2xl rounded-tl-sm p-3 max-w-sm">
                      <p className="text-sm text-gray-700">
                        🤖 A IA é como ter um assistente super inteligente que pode:
                        <br />• Responder qualquer pergunta
                        <br />• Ajudar com estudos e trabalho
                        <br />• Criar textos e resumos
                        <br />• E muito mais!
                      </p>
                    </div>

                    <div className="bg-green-600 text-white rounded-2xl rounded-tr-sm p-3 max-w-xs ml-auto">
                      <p className="text-sm">Incrível! Como faço para usar?</p>
                    </div>

                    <div className="bg-gray-100 rounded-2xl rounded-tl-sm p-3 max-w-sm">
                      <p className="text-sm text-gray-700">
                        É super fácil! Basta me adicionar no WhatsApp e começar a conversar. Estou sempre disponível! 🚀
                      </p>
                    </div>
                  </div>

                  {/* Input de Mensagem */}
                  <div className="flex items-center gap-2 pt-2 border-t border-gray-100">
                    <div className="flex-1 bg-gray-100 rounded-full px-4 py-3">
                      <p className="text-sm text-gray-500">Digite sua mensagem...</p>
                    </div>
                    <Button size="sm" className="bg-green-600 hover:bg-green-700 rounded-full p-3">
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Elementos Flutuantes */}
              <div className="absolute -top-4 -left-4 bg-white rounded-full p-3 shadow-lg">
                <Sparkles className="h-6 w-6 text-yellow-500" />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-white rounded-full p-3 shadow-lg">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Como Funciona */}
      <section id="como-funciona" className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-green-100 text-green-800 mb-4">Como Funciona</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">3 passos simples para começar</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Em menos de 1 minuto você terá acesso à IA mais avançada do mundo
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 relative">
            {/* Linha conectora */}
            <div className="hidden md:block absolute top-24 left-1/2 transform -translate-x-1/2 w-2/3 h-0.5 bg-gradient-to-r from-green-200 via-green-400 to-green-200"></div>

            {[
              {
                step: "1",
                icon: <MessageCircle className="h-8 w-8" />,
                title: "Adicione no WhatsApp",
                description: "Clique no botão, adicione nosso número em seus contatos e envie 'Oi' para começar",
                color: "from-blue-500 to-blue-600",
              },
              {
                step: "2",
                icon: <Send className="h-8 w-8" />,
                title: "Faça sua Pergunta",
                description: "Digite qualquer pergunta ou peça ajuda sobre qualquer assunto que você quiser",
                color: "from-purple-500 to-purple-600",
              },
              {
                step: "3",
                icon: <Zap className="h-8 w-8" />,
                title: "Receba a Resposta",
                description: "Obtenha respostas inteligentes e precisas em segundos, 24 horas por dia",
                color: "from-green-500 to-green-600",
              },
            ].map((item, index) => (
              <Card
                key={index}
                className="relative border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 bg-white"
              >
                <CardHeader className="text-center pb-4">
                  <div
                    className={`w-20 h-20 bg-gradient-to-br ${item.color} rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg`}
                  >
                    <div className="text-white">{item.icon}</div>
                  </div>
                  <div className="absolute -top-4 -right-4 w-10 h-10 bg-gray-900 text-white rounded-full flex items-center justify-center font-bold text-lg shadow-lg">
                    {item.step}
                  </div>
                  <CardTitle className="text-xl text-gray-900">{item.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600 leading-relaxed">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white px-8 py-4">
              <MessageCircle className="mr-2 h-5 w-5" />
              Começar Agora - É Grátis!
            </Button>
          </div>
        </div>
      </section>

      {/* Vantagens */}
      <section id="vantagens" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-green-100 text-green-800 mb-4">Vantagens</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Por que escolher o ZapGPT Pro?</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              A solução mais prática e eficiente para ter IA no seu dia a dia
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white"
              >
                <CardHeader>
                  <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mb-4">
                    {feature.icon}
                  </div>
                  <CardTitle className="text-xl text-gray-900">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Planos */}
      <section id="planos" className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-green-100 text-green-800 mb-4">Planos</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Escolha o plano ideal para você</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">Comece grátis e evolua conforme sua necessidade</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan) => (
              <Card
                key={plan.id}
                className={`relative border-2 transition-all duration-300 hover:shadow-2xl ${
                  plan.popular
                    ? "border-green-500 shadow-xl scale-105 bg-white"
                    : "border-gray-200 hover:border-green-300 bg-white hover:scale-102"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-5 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-2 text-sm font-semibold shadow-lg">
                      🔥 Mais Popular
                    </Badge>
                  </div>
                )}

                {plan.savings && (
                  <div className="absolute -top-3 -right-3">
                    <Badge className="bg-red-500 text-white px-3 py-1 text-xs font-bold">{plan.savings}</Badge>
                  </div>
                )}

                <CardHeader className="text-center pb-4">
                  <CardTitle className="text-2xl text-gray-900">{plan.name}</CardTitle>
                  <div className="mt-4">
                    <div className="flex items-center justify-center gap-2">
                      {plan.originalPrice && (
                        <span className="text-lg text-gray-400 line-through">{plan.originalPrice}</span>
                      )}
                      <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                    </div>
                    <span className="text-gray-600">{plan.period}</span>
                  </div>
                  <CardDescription className="text-gray-600 mt-2 font-medium">{plan.description}</CardDescription>
                </CardHeader>

                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    className={`w-full py-3 text-lg font-semibold ${
                      plan.popular
                        ? "bg-green-600 hover:bg-green-700 text-white shadow-lg"
                        : "border-green-600 text-green-600 hover:bg-green-50 bg-white"
                    }`}
                    variant={plan.buttonVariant}
                    size="lg"
                  >
                    {plan.buttonText}
                  </Button>

                  {plan.popular && (
                    <p className="text-center text-sm text-gray-600">⚡ Ativação instantânea • Cancele quando quiser</p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">💡 Não tem certeza? Comece com o plano gratuito!</p>
            <div className="flex items-center justify-center gap-6 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-green-600" />
                <span>Sem compromisso</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span>Cancele quando quiser</span>
              </div>
              <div className="flex items-center gap-2">
                <HeadphonesIcon className="h-4 w-4 text-green-600" />
                <span>Suporte dedicado</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Depoimentos */}
      <section id="depoimentos" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-green-100 text-green-800 mb-4">Depoimentos</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">O que nossos usuários dizem</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Mais de 50.000 pessoas já transformaram sua produtividade
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white">
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>

                  <p className="text-gray-700 mb-6 italic leading-relaxed">"{testimonial.content}"</p>

                  <div className="flex items-center gap-4">
                    <img
                      src={testimonial.avatar || "/placeholder.svg"}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                        {testimonial.verified && <CheckCircle className="h-4 w-4 text-blue-500" />}
                      </div>
                      <p className="text-sm text-gray-600">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 px-4 bg-gradient-to-br from-green-600 via-green-700 to-green-800 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full bg-[url('data:image/svg+xml,%3Csvg width=60 height=60 viewBox=0 0 60 60 xmlns=http://www.w3.org/2000/svg%3E%3Cg fill=none fillRule=evenodd%3E%3Cg fill=%23ffffff fillOpacity=0.1%3E%3Ccircle cx=30 cy=30 r=2/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')]"></div>
        </div>

        <div className="max-w-4xl mx-auto text-center relative">
          <Badge className="bg-white/20 text-white mb-6 px-4 py-2">🚀 Junte-se a mais de 50.000 usuários</Badge>

          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            Pronto para revolucionar sua produtividade?
          </h2>

          <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto leading-relaxed">
            Comece gratuitamente hoje mesmo e descubra como a IA pode transformar seu dia a dia. Sem compromisso, sem
            complicação.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button
              size="lg"
              className="bg-white text-green-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold shadow-xl"
            >
              <MessageCircle className="mr-2 h-5 w-5" />
              Começar Grátis Agora
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-white text-white hover:bg-white hover:text-green-600 px-8 py-4 text-lg bg-transparent"
            >
              Ver Demonstração
            </Button>
          </div>

          <div className="flex items-center justify-center gap-8 text-green-100 text-sm">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5" />
              <span>Grátis para sempre</span>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              <span>Dados protegidos</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              <span>Ativação instantânea</span>
            </div>
          </div>
        </div>
      </section>

      {/* Rodapé */}
      <footer className="bg-gray-900 text-white py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-green-600 rounded-xl flex items-center justify-center">
                  <MessageCircle className="h-6 w-6 text-white" />
                </div>
                <span className="text-2xl font-bold text-green-400">ZapGPT Pro</span>
              </div>
              <p className="text-gray-400 leading-relaxed">
                A forma mais inteligente e prática de usar IA no seu WhatsApp. Transforme sua produtividade hoje mesmo.
              </p>
              <div className="flex items-center gap-4">
                <Badge className="bg-green-600 text-white">50k+ usuários</Badge>
                <Badge className="bg-gray-700 text-gray-300">24/7 Online</Badge>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-white">Produto</h4>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Como Funciona
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Planos e Preços
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    API para Desenvolvedores
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Integrações
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Novidades
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-white">Suporte</h4>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Central de Ajuda
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Contato
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Status do Sistema
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Comunidade
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Tutoriais
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-white">Legal</h4>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Termos de Uso
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Política de Privacidade
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Política de Cookies
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    LGPD
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Segurança
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">© 2024 ZapGPT Pro. Todos os direitos reservados.</p>
            <div className="flex items-center gap-4 mt-4 md:mt-0">
              <p className="text-gray-400 text-sm">Feito com ❤️ no Brasil</p>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-green-500" />
                <span className="text-sm text-gray-400">SSL Seguro</span>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Botão Fixo WhatsApp */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          size="lg"
          className="bg-green-600 hover:bg-green-700 text-white rounded-full w-16 h-16 shadow-2xl hover:shadow-3xl transition-all duration-300 animate-pulse hover:animate-none hover:scale-110"
        >
          <MessageCircle className="h-8 w-8" />
        </Button>

        {/* Tooltip */}
        <div className="absolute bottom-20 right-0 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 hover:opacity-100 transition-opacity pointer-events-none">
          Fale conosco no WhatsApp
          <div className="absolute top-full right-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
        </div>
      </div>
    </div>
  )
}
